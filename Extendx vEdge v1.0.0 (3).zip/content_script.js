(async function () {
  if (location.protocol === 'chrome-extension:' ||
      location.protocol === 'chrome:' ||
      location.protocol === 'about:') return;

  const s = await chrome.storage.local.get(null);

  let lastUserGesture = 0;
  document.addEventListener('mousedown', () => { lastUserGesture = Date.now(); }, true);
  document.addEventListener('keydown',   () => { lastUserGesture = Date.now(); }, true);

  function isRandomString(str) {
    if (!str || str.length < 7) return false;
    const chars = str.replace(/[-_]/g, '');
    if (chars.length < 5) return false;
    const freq = {};
    for (const c of chars) freq[c] = (freq[c] || 0) + 1;
    let entropy = 0;
    for (const c in freq) {
      const p = freq[c] / chars.length;
      entropy -= p * Math.log2(p);
    }
    if (entropy > 3.3 && chars.length >= 10) return true;
    const vowels = new Set(['a','e','i','o','u','y']);
    const alpha = chars.split('').filter(c => /[a-z]/i.test(c));
    if (alpha.length >= 7) {
      const cr = alpha.filter(c => !vowels.has(c.toLowerCase())).length / alpha.length;
      if (cr > 0.82) return true;
    }
    const digits = chars.split('').filter(c => /\d/.test(c)).length;
    if (digits >= 4 && digits / chars.length > 0.4 && chars.length >= 9) return true;
    return false;
  }

  function logCS(entry) {
    try {
      chrome.storage.local.get('logs', d => {
        const logs = d.logs || [];
        logs.unshift({ ts: Date.now(), ...entry });
        if (logs.length > 2000) logs.length = 2000;
        chrome.storage.local.set({ logs });
      });
    } catch(e) {}
  }

  // Page-level redirect checks
  if (s.blockSuspiciousTLDs) {
    const host = location.hostname;
    const tld = host.split('.').pop();
    if ((s.tldList || []).includes(tld)) {
      logCS({ type: 'blocked_tld', host, tld, blocked: true });
      location.replace(chrome.runtime.getURL(
        `blocked.html?reason=tld&host=${encodeURIComponent(host)}&tld=${encodeURIComponent(tld)}`));
      return;
    }
  }

  for (const domain of (s.blockedDomains || [])) {
    if (location.hostname === domain || location.hostname.endsWith(`.${domain}`)) {
      logCS({ type: 'blocked_domain', host: location.hostname, blocked: true });
      location.replace(chrome.runtime.getURL(
        `blocked.html?reason=domain&host=${encodeURIComponent(location.hostname)}`));
      return;
    }
  }

  if (s.blockHttp && location.protocol === 'http:') {
    logCS({ type: 'blocked_http', host: location.hostname, blocked: true });
    location.replace(chrome.runtime.getURL(
      `blocked.html?reason=http&host=${encodeURIComponent(location.hostname)}`));
    return;
  }

  if (s.blockRandomDomains) {
    const parts = location.hostname.split('.');
    const domainPart = parts.length >= 2 ? parts[parts.length - 2] : parts[0];
    if (isRandomString(domainPart)) {
      logCS({ type: 'blocked_random', host: location.hostname, blocked: true });
      location.replace(chrome.runtime.getURL(
        `blocked.html?reason=random&host=${encodeURIComponent(location.hostname)}`));
      return;
    }
    if (s.blockRandomSubdomains && parts.length > 2) {
      const sub = parts.slice(0, -2).join('.');
      if (isRandomString(sub)) {
        logCS({ type: 'blocked_random', host: location.hostname, blocked: true });
        location.replace(chrome.runtime.getURL(
          `blocked.html?reason=random&host=${encodeURIComponent(location.hostname)}`));
        return;
      }
    }
  }

  // Deep chain TLD blocking: if document.referrer comes from a blocked TLD, taint this page
  if (s.deepChainTlds && s.blockSuspiciousTLDs) {
    try {
      if (document.referrer) {
        const refHost = new URL(document.referrer).hostname;
        const refTld = refHost.split('.').pop();
        if ((s.tldList || []).includes(refTld)) {
          logCS({ type: 'blocked_deep_tld', host: location.hostname, tld: refTld, blocked: true });
          location.replace(chrome.runtime.getURL(
            `blocked.html?reason=deep&host=${encodeURIComponent(location.hostname)}&tld=${encodeURIComponent(refTld)}`));
          return;
        }
      }
      // Also observe sub-resource loads with suspicious TLD hostnames via PerformanceObserver
      const tlds = s.tldList || [];
      try {
        const obs = new PerformanceObserver((list) => {
          for (const e of list.getEntries()) {
            try {
              const u = new URL(e.name);
              const t = u.hostname.split('.').pop();
              if (tlds.includes(t)) {
                logCS({ type: 'blocked_deep_tld', host: location.hostname, tld: t, blocked: true });
                location.replace(chrome.runtime.getURL(
                  `blocked.html?reason=deep&host=${encodeURIComponent(location.hostname)}&tld=${encodeURIComponent(t)}`));
              }
            } catch(e) {}
          }
        });
        obs.observe({ type: 'resource', buffered: true });
      } catch(e) {}
    } catch(e) {}
  }

  // JS redirect blocking + optional false-positive simulation
  if (s.blockJsRedirects || s.blockAllRedirects || s.blockWebsiteRedirects) {
    const wl = s.redirectWhitelist || [];
    const whitelisted = wl.some(d => location.hostname.includes(d));

    if (!whitelisted) {
      const blockAll     = !!s.blockAllRedirects;
      const blockWebsite = !!s.blockWebsiteRedirects;
      const returnFP     = !!s.redirectReturnFalse;
      const simulate     = !!s.redirectSimulate;
      const curHost      = location.hostname;

      const script = document.createElement('script');
      script.textContent = `(()=>{
        const _blockAll     = ${blockAll};
        const _blockWebsite = ${blockWebsite};
        const _returnFP     = ${returnFP};
        const _simulate     = ${simulate};
        const _host         = ${JSON.stringify(curHost)};
        let _lastGesture    = 0;
        document.addEventListener('mousedown', () => { _lastGesture = Date.now(); }, true);
        document.addEventListener('keydown',   () => { _lastGesture = Date.now(); }, true);

        function _ext(url) {
          try { return new URL(url, location.href).hostname !== _host; } catch(e) { return false; }
        }
        function _hasGesture() { return (Date.now() - _lastGesture) < 1000; }
        function _shouldBlock(url) {
          if (!_ext(url)) return false;
          if (_blockAll)     return !_hasGesture();
          if (_blockWebsite) return !_hasGesture();
          return true;
        }
        function _report(kind, url) {
          try { window.postMessage({ __extendx: true, kind, url }, '*'); } catch(e) {}
        }
        function _simulateNavigation(url) {
          // Simulate redirect success via history.replaceState so page code thinks navigation happened.
          // Stay on the same actual page but update URL bar minimally.
          try {
            const u = new URL(url, location.href);
            // Only safe to replaceState within same origin; otherwise skip simulation.
            if (u.origin === location.origin) {
              history.replaceState(null, '', u.pathname + u.search + u.hash);
              window.dispatchEvent(new PopStateEvent('popstate'));
            }
            window.dispatchEvent(new HashChangeEvent('hashchange'));
          } catch(e) {}
        }

        const _oAssign  = Location.prototype.assign;
        const _oReplace = Location.prototype.replace;
        Location.prototype.assign  = function(u){
          if(!_shouldBlock(u)) return _oAssign.call(this, u);
          _report(_blockWebsite && !_blockAll ? 'blocked_redirect_website' : 'blocked_redirect', u);
          if(_simulate) _simulateNavigation(u);
          if(!_returnFP) console.warn('[Extendx] Blocked redirect to:', u);
        };
        Location.prototype.replace = function(u){
          if(!_shouldBlock(u)) return _oReplace.call(this, u);
          _report(_blockWebsite && !_blockAll ? 'blocked_redirect_website' : 'blocked_redirect', u);
          if(_simulate) _simulateNavigation(u);
          if(!_returnFP) console.warn('[Extendx] Blocked redirect to:', u);
        };

        try {
          const _d = Object.getOwnPropertyDescriptor(Location.prototype,'href');
          Object.defineProperty(Location.prototype,'href',{
            get: _d.get,
            set: function(v){
              if(!_shouldBlock(v)) return _d.set.call(this, v);
              _report(_blockWebsite && !_blockAll ? 'blocked_redirect_website' : 'blocked_redirect', v);
              if(_simulate) _simulateNavigation(v);
              if(!_returnFP) console.warn('[Extendx] Blocked href redirect to:', v);
            },
            configurable: true
          });
        } catch(e){}

        const _oOpen = window.open;
        window.open = function(url, target, features){
          if(url && _ext(url) && !_hasGesture()){
            _report('blocked_popup', url);
            if(!_returnFP) console.warn('[Extendx] Blocked window.open to:', url);
            // false-positive: return a stub window-like object so page code does not throw
            if(_simulate) {
              return { closed:false, close:function(){this.closed=true;}, focus:function(){}, blur:function(){}, postMessage:function(){}, location:{href:url,assign:function(){},replace:function(){}}, document:{} };
            }
            return null;
          }
          return _oOpen.call(window, url, target, features);
        };

        // history.pushState / replaceState cross-origin checks (rarely cross-origin, but cover anchor changes)
        // Anchor click interception
        document.addEventListener('click', function(ev){
          const a = ev.target && ev.target.closest && ev.target.closest('a[href]');
          if (!a) return;
          const href = a.getAttribute('href');
          if (!href) return;
          if (_shouldBlock(href)) {
            ev.preventDefault();
            ev.stopPropagation();
            _report(_blockWebsite && !_blockAll ? 'blocked_redirect_website' : 'blocked_redirect', href);
            if(_simulate) _simulateNavigation(href);
          }
        }, true);
      })();`;
      document.documentElement.appendChild(script);
      script.remove();

      window.addEventListener('message', (ev) => {
        if (!ev.data || !ev.data.__extendx) return;
        logCS({ type: ev.data.kind, host: location.hostname, redirectTo: ev.data.url, blocked: true });
      });
    }
  }

  if (s.blockMetaRefresh) {
    const removeMetaTags = () =>
      document.querySelectorAll('meta[http-equiv="refresh"]').forEach(m => {
        logCS({ type: 'blocked_meta', host: location.hostname, blocked: true });
        m.remove();
      });
    removeMetaTags();
    new MutationObserver(removeMetaTags)
      .observe(document.documentElement, { childList: true, subtree: true });
  }

  if ((s.blockPopups || s.blockAdPopups) && !(s.blockJsRedirects || s.blockAllRedirects || s.blockWebsiteRedirects)) {
    const wl = s.popupWhitelist || [];
    if (!wl.some(d => location.hostname.includes(d))) {
      const script = document.createElement('script');
      script.textContent = `(()=>{
        let _lg = 0;
        document.addEventListener('mousedown', () => { _lg = Date.now(); }, true);
        document.addEventListener('keydown',   () => { _lg = Date.now(); }, true);
        const _oOpen = window.open;
        window.open = function(url, target, features){
          if ((Date.now() - _lg) < 1000) return _oOpen.call(window, url, target, features);
          try { window.postMessage({ __extendx: true, kind: 'blocked_popup', url: url || '' }, '*'); } catch(e){}
          console.warn('[Extendx] Blocked popup');
          return null;
        };
      })();`;
      document.documentElement.appendChild(script);
      script.remove();
      window.addEventListener('message', (ev) => {
        if (!ev.data || !ev.data.__extendx || ev.data.kind !== 'blocked_popup') return;
        logCS({ type: 'blocked_popup', host: location.hostname, redirectTo: ev.data.url, blocked: true });
      });
    }
  }

  if (s.blockWebRTC) {
    const wl = s.webrtcList || [];
    if (!wl.some(d => location.hostname.includes(d))) {
      const script = document.createElement('script');
      script.textContent = `(()=>{
        ['RTCPeerConnection','webkitRTCPeerConnection','mozRTCPeerConnection'].forEach(n=>{
          if(!window[n]) return;
          const O = window[n];
          window[n] = function(c){ if(c) c.iceServers=[]; return new O(c); };
          window[n].prototype = O.prototype;
        });
      })();`;
      document.documentElement.appendChild(script);
      script.remove();
    }
  } else if (s.blockSTUN) {
    const script = document.createElement('script');
    script.textContent = `(()=>{
      ['RTCPeerConnection','webkitRTCPeerConnection','mozRTCPeerConnection'].forEach(n=>{
        if(!window[n]) return;
        const O = window[n];
        window[n] = function(c){
          if(c && c.iceServers)
            c.iceServers = c.iceServers.filter(s=>{
              const u = typeof s.urls==='string'?[s.urls]:s.urls||[];
              return !u.some(x=>x.startsWith('stun:'));
            });
          return new O(c);
        };
        window[n].prototype = O.prototype;
      });
    })();`;
    document.documentElement.appendChild(script);
    script.remove();
  }

  if (s.blockAutoplayVideo || s.blockAutoplayAudio) {
    const wl = s.autoplayList || [];
    if (!wl.some(d => location.hostname.includes(d))) {
      document.addEventListener('play', e => {
        const t = e.target;
        if (!t) return;
        if (t.tagName === 'VIDEO' && s.blockAutoplayVideo && !t.hasAttribute('controls')) t.pause();
        if (t.tagName === 'AUDIO' && s.blockAutoplayAudio && !t.hasAttribute('controls')) t.pause();
      }, true);
    }
  }

  if (s.blockCrossForm) {
    document.addEventListener('submit', e => {
      const form = e.target;
      try {
        const actionHost = new URL(form.action || location.href, location.href).hostname;
        const wl = s.formList || [];
        if (actionHost !== location.hostname && !wl.some(d => actionHost.includes(d))) {
          e.preventDefault();
          e.stopPropagation();
          logCS({ type: 'blocked_form', host: location.hostname, redirectTo: actionHost, blocked: true });
        }
      } catch (err) {}
    }, true);
  }

  if (s.enableCSP && !s.allowInline) {
    document.querySelectorAll('script:not([src])').forEach(el => el.remove());
    new MutationObserver(muts => muts.forEach(m =>
      m.addedNodes.forEach(n => {
        if (n.nodeType === 1 && n.tagName === 'SCRIPT' && !n.src) n.remove();
      })
    )).observe(document.documentElement, { childList: true, subtree: true });
  }
})();
