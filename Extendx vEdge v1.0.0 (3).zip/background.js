const MAX_RULES = 5000;

const DEFAULT_TLDS = ['zip','mov','xyz','top','tk','ml','ga','cf','gq','click','country','stream','download','racing','accountant','science','review','party','date','trade','win','loan','men','work','bid','cricket','faith','kim','rocks','wang','space'];

async function getAllSettings() {
  return chrome.storage.local.get(null);
}

function logEvent(entry) {
  chrome.storage.local.get('logs', d => {
    const logs = d.logs || [];
    logs.unshift({ ts: Date.now(), ...entry });
    if (logs.length > 2000) logs.length = 2000;
    chrome.storage.local.set({ logs });
  });
}

async function rebuildRules() {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  const ids = existing.map(r => r.id);
  if (ids.length) await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ids });
  await applyRules();
}

async function applyRules() {
  const s = await getAllSettings();
  const rules = [];
  let id = 1;

  if (s.blockSuspiciousTLDs) {
    (s.tldList || []).forEach(t => {
      if (id > MAX_RULES) return;
      rules.push({
        id: id++, priority: 1,
        action: { type: 'block' },
        condition: {
          urlFilter: `.${t}/`,
          resourceTypes: ['main_frame','sub_frame','xmlhttprequest','script','image','stylesheet','object','other','media','font','websocket']
        }
      });
    });
  }

  (s.blockedDomains || []).forEach(domain => {
    if (id > MAX_RULES) return;
    rules.push({
      id: id++, priority: 2,
      action: { type: 'block' },
      condition: {
        urlFilter: `||${domain}^`,
        resourceTypes: ['main_frame','sub_frame','xmlhttprequest','script','image','stylesheet','object','other','media','font','websocket']
      }
    });
  });

  (s.trackerList || []).forEach(d => {
    if (id > MAX_RULES) return;
    rules.push({
      id: id++, priority: 1,
      action: { type: 'block' },
      condition: { urlFilter: d, resourceTypes: ['script','xmlhttprequest','image','sub_frame'] }
    });
  });

  const NAMED = [
    { key: 'blockGA',     filter: 'google-analytics.com' },
    { key: 'blockFB',     filter: 'facebook.net' },
    { key: 'blockTT',     filter: 'tiktok.com' },
    { key: 'blockHotjar', filter: 'hotjar.com' },
  ];

  NAMED.forEach(({ key, filter }) => {
    if (s[key] && id <= MAX_RULES) {
      rules.push({
        id: id++, priority: 1,
        action: { type: 'block' },
        condition: { urlFilter: filter, resourceTypes: ['main_frame','script','xmlhttprequest','image','sub_frame'] }
      });
    }
  });

  if (s.blockExternalScripts) {
    // BUG 4 FIX: only expand CDN list when allowCDN is true
    const cdn = (s.allowCDN && s.cdnList) ? s.cdnList : [];
    const cdnSrc = cdn.map(d => `https://${d} http://${d}`).join(' ');
    const cspVal = `script-src 'self' 'unsafe-inline'${cdnSrc ? ' ' + cdnSrc : ''}`;
    if (id <= MAX_RULES) {
      rules.push({
        id: id++, priority: 3,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [{ header: 'Content-Security-Policy', operation: 'set', value: cspVal }]
        },
        // BUG 3 FIX: |http matches both http:// and https://
        condition: { urlFilter: '|http', resourceTypes: ['main_frame','sub_frame'] }
      });
    }
  }

  if (s.enableCSP && !s.blockExternalScripts) {
    const cspVal = s.allowInline ? "script-src 'self' 'unsafe-inline'" : "script-src 'self'";
    if (id <= MAX_RULES) {
      rules.push({
        id: id++, priority: 4,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [{ header: 'Content-Security-Policy', operation: 'set', value: cspVal }]
        },
        condition: { urlFilter: '|http', resourceTypes: ['main_frame','sub_frame'] }
      });
    }
  }

  if (s.blockAllRequests && id <= MAX_RULES) {
    rules.push({
      id: id++, priority: 2,
      action: { type: 'block' },
      condition: {
        resourceTypes: ['xmlhttprequest','sub_frame','script','image','stylesheet','media','font','websocket'],
        urlFilter: '|http'
      }
    });
  }

  if (rules.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules.slice(0, MAX_RULES) });
  }
}

// NOTE: keep in sync with content_script.js
function isRandomString(str) {
  if (!str || str.length < 7) return false;
  const chars = str.replace(/[-_]/g, '');
  if (chars.length < 5) return false;
  const freq = {};
  for (const c of chars) freq[c] = (freq[c] || 0) + 1;
  let entropy = 0;
  for (const c in freq) {
    const p = freq[c] / chars.length;
    entropy -= p * Math.log2(p);
  }
  if (entropy > 3.3 && chars.length >= 10) return true;
  const vowels = new Set(['a','e','i','o','u','y']);
  const alpha = chars.split('').filter(c => /[a-z]/i.test(c));
  if (alpha.length >= 7) {
    const cr = alpha.filter(c => !vowels.has(c.toLowerCase())).length / alpha.length;
    if (cr > 0.82) return true;
  }
  const digits = chars.split('').filter(c => /\d/.test(c)).length;
  if (digits >= 4 && digits / chars.length > 0.4 && chars.length >= 9) return true;
  return false;
}

function getBlockedPageUrl(rawUrl, s) {
  try {
    const url = new URL(rawUrl);
    if (!url.protocol || !url.hostname) return null;
    // BUG 6: guard for non-http(s) URLs - prevents redirecting chrome://, chrome-extension:// etc.
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
    const host = url.hostname;
    if (s.blockSuspiciousTLDs) {
      const tld = host.split('.').pop();
      if ((s.tldList || []).includes(tld)) {
        return chrome.runtime.getURL(`blocked.html?reason=tld&tld=${encodeURIComponent(tld)}&host=${encodeURIComponent(host)}`);
      }
    }
    for (const domain of (s.blockedDomains || [])) {
      if (host === domain || host.endsWith(`.${domain}`)) {
        return chrome.runtime.getURL(`blocked.html?reason=domain&host=${encodeURIComponent(host)}`);
      }
    }
    if (s.blockHttp && url.protocol === 'http:') {
      return chrome.runtime.getURL(`blocked.html?reason=http&host=${encodeURIComponent(host)}`);
    }
    if (s.blockRandomDomains) {
      const parts = host.split('.');
      const domainPart = parts.length >= 2 ? parts[parts.length - 2] : parts[0];
      if (domainPart && isRandomString(domainPart)) {
        return chrome.runtime.getURL(`blocked.html?reason=random&host=${encodeURIComponent(host)}`);
      }
      if (s.blockRandomSubdomains && parts.length > 2) {
        const sub = parts.slice(0, -2).join('.');
        if (sub && isRandomString(sub)) {
          return chrome.runtime.getURL(`blocked.html?reason=random&host=${encodeURIComponent(host)}`);
        }
      }
    }
    return null;
  } catch (e) {
    return null;
  }
}

async function checkOpenTabs() {
  const s = await getAllSettings();
  let tabs;
  try { tabs = await chrome.tabs.query({}); } catch (e) { return; }
  for (const tab of tabs) {
    if (!tab.url || !tab.id) continue;
    const blockUrl = getBlockedPageUrl(tab.url, s);
    if (blockUrl) {
      try { await chrome.tabs.update(tab.id, { url: blockUrl }); } catch (e) {}
    }
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(['tldList','language']);
  const patch = {};
  if (!cur.tldList) patch.tldList = DEFAULT_TLDS.slice();
  if (!cur.language) patch.language = 'en';
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
  rebuildRules();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'settingsChanged') { rebuildRules(); checkOpenTabs(); }
  if (msg.type === 'openPopup') { try { chrome.action.openPopup(); } catch (e) {} }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const s = await getAllSettings();
  const blockUrl = getBlockedPageUrl(changeInfo.url, s);
  if (blockUrl) {
    try { await chrome.tabs.update(tabId, { url: blockUrl }); } catch (e) {}
  }
});

chrome.downloads.onCreated.addListener(async item => {
  const s = await getAllSettings();
  // BUG 5 FIX: exempt any blob URL from the extension itself
  if (!item.url || item.url.startsWith('blob:')) return;
  if (!s.blockAutoDownloads) return;
  if (s.selectiveExt) {
    const extList = (s.extList || []).map(e => e.toLowerCase().replace(/^\./, ''));
    if (!extList.length) return;
    const urlPath = (item.url || '').split('?')[0].split('#')[0];
    const fn = (item.filename || urlPath.split('/').pop() || '');
    const ext = fn.split('.').pop().toLowerCase();
    if (extList.includes(ext)) {
      try { chrome.downloads.cancel(item.id); } catch (e) {}
      logEvent({ type: 'blocked_ext', url: item.url, ext, blocked: true });
    }
  } else {
    try { chrome.downloads.cancel(item.id); } catch (e) {}
    logEvent({ type: 'download_cancelled', url: item.url, blocked: true });
  }
});

rebuildRules();
checkOpenTabs();
