(function () {
  const params = new URLSearchParams(location.search);
  const reason = params.get('reason') || 'domain';
  const host = params.get('host') || '';
  const tld = params.get('tld') || '';

  const T = {
    en: {
      subtitle: 'Connection blocked',
      ask: 'Ask Gemini inside Extendx',
      domain: (h) => `This connection has been blocked by Extendx v1.0 vEdge.\n\nThe domain "${h}" is on your blacklist.`,
      http:   (h) => `This connection has been blocked by Extendx v1.0 vEdge.\n\nThe site "${h}" uses unsecured HTTP. Your settings require HTTPS only.`,
      random: (h) => `This connection has been blocked by Extendx v1.0 vEdge.\n\nThe domain "${h}" looks like a randomly generated string, which is a common pattern for malicious or throwaway sites.`,
      tld:    (h, t) => `This connection has been blocked by Extendx v1.0 vEdge.\n\nThe domain "${h}" uses the suspicious top level domain ".${t}", which is on your blocklist.`,
      deep:   (h, t) => `This connection has been blocked by Extendx v1.0 vEdge.\n\nThe page "${h}" received content from the suspicious top level domain ".${t}" (deep chain TLD blocking).`,
    },
    pl: {
      subtitle: 'Połączenie zablokowane',
      ask: 'Zapytaj Gemini wewnątrz Extendx',
      domain: (h) => `To połączenie zostało zablokowane przez Extendx v1.0 vEdge.\n\nDomena "${h}" znajduje się na Twojej czarnej liście.`,
      http:   (h) => `To połączenie zostało zablokowane przez Extendx v1.0 vEdge.\n\nStrona "${h}" używa niezabezpieczonego HTTP. Twoje ustawienia wymagają HTTPS.`,
      random: (h) => `To połączenie zostało zablokowane przez Extendx v1.0 vEdge.\n\nDomena "${h}" wygląda na losowo wygenerowaną, co jest częste w przypadku złośliwych lub jednorazowych stron.`,
      tld:    (h, t) => `To połączenie zostało zablokowane przez Extendx v1.0 vEdge.\n\nDomena "${h}" używa podejrzanej końcówki ".${t}", która znajduje się na liście blokowania.`,
      deep:   (h, t) => `To połączenie zostało zablokowane przez Extendx v1.0 vEdge.\n\nStrona "${h}" otrzymała treść z podejrzanej końcówki ".${t}" (głębokie blokowanie łańcuchów TLD).`,
    },
    ru: {
      subtitle: 'Соединение заблокировано',
      ask: 'Спросить Gemini внутри Extendx',
      domain: (h) => `Это соединение заблокировано Extendx v1.0 vEdge.\n\nДомен "${h}" находится в чёрном списке.`,
      http:   (h) => `Это соединение заблокировано Extendx v1.0 vEdge.\n\nСайт "${h}" использует незащищённый HTTP. Ваши настройки требуют только HTTPS.`,
      random: (h) => `Это соединение заблокировано Extendx v1.0 vEdge.\n\nДомен "${h}" выглядит как случайно сгенерированная строка, что характерно для вредоносных сайтов.`,
      tld:    (h, t) => `Это соединение заблокировано Extendx v1.0 vEdge.\n\nДомен "${h}" использует подозрительный TLD ".${t}".`,
      deep:   (h, t) => `Это соединение заблокировано Extendx v1.0 vEdge.\n\nСтраница "${h}" получила контент из подозрительной TLD ".${t}" (глубокая блокировка цепочек).`,
    }
  };

  chrome.storage.local.get(['language', 'geminiApiKey'], d => {
    const lang = (d && d.language && T[d.language]) ? d.language : 'en';
    const tt = T[lang];
    document.getElementById('subtitle').textContent = tt.subtitle;
    let msg = '';
    if (reason === 'tld')         msg = tt.tld(host, tld);
    else if (reason === 'deep')   msg = tt.deep(host, tld);
    else if (reason === 'http')   msg = tt.http(host);
    else if (reason === 'random') msg = tt.random(host);
    else                          msg = tt.domain(host);
    document.getElementById('message').textContent = msg;

    const canAsk = !!(d && d.geminiApiKey);

    const ask = document.getElementById('askGemini');
    ask.textContent = tt.ask;
    if (canAsk) {
      ask.classList.add('visible');
      ask.addEventListener('click', () => {
        chrome.storage.local.set({ pendingBlockedContext: msg }, () => {
          try { chrome.runtime.sendMessage({ type: 'openPopup' }); } catch (e) {}
        });
      });
    }
  });
})();
